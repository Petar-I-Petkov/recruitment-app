import { Route,Switch } from 'react-router-dom';
import './App.css';

import Header from './components/Header/Header'
import JobAdd from './components/JobAdd/JobAdd'
import JobAll from './components/JobAll/JobAll'
import JobEdit from './components/JobEdit/JobEdit'
import CandidatesAll from './components/CandidatesAll/CandidatesAll'


function App() {
  return (
    <div className="App">

      <Header />
      <Switch>

        <Route path="/jobs/add" component={JobAdd} />
        <Route path="/jobs/all" component={JobAll} />
        <Route path="/jobs/edit/:jobId" exact component={JobEdit} />
        <Route path="/candidates/all" component={CandidatesAll} />



      </Switch>
      {/* <Footer /> */}
    </div>
  );
}

export default App;
