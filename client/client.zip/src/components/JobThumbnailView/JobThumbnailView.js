import { Link } from 'react-router-dom';
import { useState,useEffect } from 'react';

import './JobThumbnailView.css'

import * as candidateservice from '../../services/candidateservice'

const JobThumbnailView = ({
    _id,
    title,
    description,
    candidates,

}) => {

    const [allCandidates,setAllCandidates] = useState([]);
    const [selectedCandidate,setSelectedCandidate] = useState([]);

    useEffect(() => {
        candidateservice.findAll()
            .then(res => {
                setAllCandidates(res);
            })
            .catch(err => { console.log(err) });
    },[]);

    const onDropdownListChangeHandler = (e) => {
        e.preventDefault();
        let select = document.getElementById('candidates')
        console.log(select[select.selectedIndex].id);


        //todo -> make a put request with an array to add the candidate


    }

    const onAddCandidateClickHandler = (e) => {
        e.preventDefault();
        console.log(e);

    }




    return (
        <article className="item-thumbnail">
            <section className="item-thumbnail-top">
                <section className="item-thumbnail-left">
                    <p className="item-thumbnail-title">{title}</p>
                    <p className="item-thumbnail-description">{description}</p>

                </section>
                <section className="item-thumbnail-right">
                    <button className="button-round-shadow-no" type="button"><Link to={`/jobs/edit/${_id}`} >Edit</Link></button>
                </section>
            </section>
            <section className="item-thumbnail-bottom">
                <section className="bottom-left">
                    <nav>
                        <li>'TODO - RENDER LIST OF CANDIDATES'</li>

                    </nav>
                </section>
                <section className="bottom-right">
                    <select id="candidates" onChange={onDropdownListChangeHandler}>
                        {allCandidates.map(candidate => (
                            <option
                                id={candidate._id}
                                key={candidate._id}
                                value={`${candidate.firstName} ${candidate.lastName}`}>
                                {`${candidate.firstName} ${candidate.lastName}`}
                            </option>
                        ))}
                    </select>
                    <button className="button-round-shadow-no" onClick={onAddCandidateClickHandler}>Add Candidate</button>
                </section>

            </section>


        </article>
    )


}


export default JobThumbnailView;