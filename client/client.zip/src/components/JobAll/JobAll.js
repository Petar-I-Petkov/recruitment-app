import { useState,useEffect } from 'react'


import JobsMenu from '../JobsMenu/JobsMenu';
import JobsThumbnailView from '../JobThumbnailView/JobThumbnailView'
import * as jobservice from '../../services/jobservice';



const JobAdd = () => {

    const [jobs,setJobs] = useState([]);

    useEffect(() => {
        jobservice
            .findAll()
            .then(allJobs => {
                setJobs(allJobs);
            })
            .catch(err => console.error(err));

    },[]);


    return (
        <main>
            <JobsMenu />
            <section className="thumbnails-container">
                <h1>All Jobs List:</h1>
                {jobs.map(job => <JobsThumbnailView
                    key={job._id}
                    _id={job._id}
                    title={job.title}
                    description={job.description}
                />)}

            </section>

        </main>
    )
}

export default JobAdd;