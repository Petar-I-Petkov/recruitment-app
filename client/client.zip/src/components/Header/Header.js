import { Component } from "react";
import { Link } from 'react-router-dom'
import { withRouter } from "react-router";
import './Header.css';

// import * as userService from '../../services/userService'
// import AuthContext from '../../contexts/AuthContext'
// import { renderInfo } from '../../utils/notificationPlugin/notificationPlugin'




class Header extends Component {

    // eslint-disable-next-line no-useless-constructor
    constructor(props) {
        super(props)
        this.state = {
        }
    }



    render() {

        return (
            <header>
                <section className="header-left">

                    <section className="logo-container">
                        <img src="https://thumbs.dreamstime.com/b/creative-hr-logo-icon-design-simple-clean-crisp-vector-format-170799177.jpg" alt="" />
                    </section>
                    <section className="header-greeting">
                        Welcome, HR Specialist!
                    </section>
                </section>
                <nav className="header-nav">
                    <ul className="header-nav-list rem-09">
                        <li className="header-nav-li-item"><Link to="/home">Home</Link></li>
                        <li className="header-nav-li-item"><Link to="/interviews/all">Interviews</Link></li>
                        <li className="header-nav-li-item"><Link to="/jobs/all">Jobs</Link></li>
                        <li className="header-nav-li-item"><Link to="/candidates/all">Candidates</Link></li>

                    </ul>
                    <div className="blue-circle-container ml-10" >
                        <p className="blue-circle">HR</p>
                    </div>
                </nav>
            </header >

        )
    }
}

export default withRouter(Header);