import { useState,useEffect } from 'react'
import * as candidateservice from '../../services/candidateservice'

import CandidateThumbnailView from '../CandidateThumbnailView/CandidateThumbnailView'

const CandidatesAll = () => {

    const [candidates,setCandidates] = useState([]);

    useEffect(() => {
        candidateservice
            .findAll()
            .then(res => {
                setCandidates(res);
            })
            .catch(err => console.error(err));

    },[]);

    return (
        <main>

            <section className="thumbnails-container">
                <h1>All Candidates List:</h1>
                {candidates.map(candidate =>
                    <CandidateThumbnailView
                        key={candidate._id}
                        _id={candidate._id}
                        firstName={candidate.firstName}
                        lastName={candidate.lastName}
                    />)}

            </section>

        </main>)



}


export default CandidatesAll;