import { useState,useEffect,useContext } from 'react';
import * as jobservice from '../../services/jobservice';
import { Link,useHistory } from 'react-router-dom';

import * as notificationPlugin from '../../utils/notificationPlugin/notificationPlugin'




const JobEdit = ({
    match
}) => {

    const history = useHistory();
    const [job,setJob] = useState({});

    useEffect(() => {
        jobservice.getOne(match.params.jobId)
            .then(res => {
                setJob(res);
            })
            .catch(err => { console.log(err) });
    },[]);



    const onJobDeleteClickHandler = (e) => {
        e.preventDefault();
        jobservice
            .deleteById(job._id)
            .then((response) => { history.push('/jobs/all') })
    }

    const onJobSubmitChangesFunction = (e) => {
        e.preventDefault();
        jobservice.update(job).then(res => {

            history.push(`/jobs/all`)
            notificationPlugin.renderInfo({ message: `Resource updated successfully!` })

        });
    }




    return (
        <main>
            <article className="item-details">
                <section className="item-details-top">
                    <form className="form-global">
                        <label htmlFor="title">Job Title:</label>
                        <input
                            type="text" name="title" placeholder="Theater name"
                            value={job.title || ''} onChange={(e) => setJob({ ...job,title: e.target.value })}
                        />
                        <label htmlFor="title">Job Title:</label>
                        <input
                            type="text" name="title" placeholder="Theater name"
                            value={job.description || ''} onChange={(e) => setJob({ ...job,description: e.target.value })}
                        />
                    </form>



                </section>
                <section className="item-details-bottom">
                    <button className="button-round-shadow-no" type="button" onClick={onJobSubmitChangesFunction}>Submit Changes</button>
                    <button
                        className="button-round-shadow-no delete-btn" type="button">
                        <Link to="/jobs/delete"
                            onClick={onJobDeleteClickHandler}>
                            Delete Job Permanently
                        </Link>
                    </button>
                </section>
            </article>

        </main>
    )
}

export default JobEdit;