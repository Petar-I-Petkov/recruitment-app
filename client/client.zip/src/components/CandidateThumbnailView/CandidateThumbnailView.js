
import { Link } from 'react-router-dom'
import './CandidateThumbnailView.css'


const CandidateThumbnailView = (
    {
        _id,
        firstName,
        lastName,
    }
) => {


    return (

        <article className="item-thumbnail candidate">
            <section className="item-thumbnail-left">
                <p className="item-thumbnail-title">{firstName}</p>
                <p className="item-thumbnail-description">{lastName}</p>
            </section>

            <section className="item-thumbnail-right">
                <button className="button-round-shadow-no" type="button"><Link to={`/candidates/edit/${_id}`} >Edit</Link></button>
            </section>


        </article>
    )
}

export default CandidateThumbnailView;