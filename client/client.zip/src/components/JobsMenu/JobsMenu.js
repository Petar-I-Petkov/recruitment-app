import { Link } from 'react-router-dom'



const JobAdd = () => {


    return (
        <section className="sub-menu-top-section job-actions">
            <nav className="horizontal-nav-list">
                <li className="button-round-shadow-no" ><Link to="/jobs/add">Add new Job</Link></li>
            </nav>
        </section>
    )
}

export default JobAdd;