import ReactDom from 'react-dom';
import Notification from './Notification/Notification'

const renderInNotificationPortal = (messagesObj,boxType) => {
    document.getElementById('notification-portal')
        ?
        ReactDom.render(
            <Notification
                messagesObj={messagesObj}
                boxType={boxType}
            />
            ,document.getElementById('notification-portal')
        )
        : console.error({ error: `[notificationPlugin.js] container with id 'notification-portal' not found!`,message: messagesObj })
}

export function renderErrors(errorMessagesObj) {
    renderInNotificationPortal(errorMessagesObj,'errorBox')
}

export function renderInfo(infoMessagesObj) {
    renderInNotificationPortal(infoMessagesObj,'infoBox')
}

export function renderLoadingBox(loadingMessagesObj) {
    renderInNotificationPortal(loadingMessagesObj,'infoBox')
}

